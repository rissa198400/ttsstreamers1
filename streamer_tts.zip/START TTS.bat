@echo off
cd /d "%~dp0"
pip install pywin32 keyboard >nul 2>&1
python streamer_tts.py
