"""
Streamer TTS — Windows Desktop App
Requires: pip install pywin32 keyboard
Run: python streamer_tts.py
"""

import tkinter as tk
from tkinter import ttk, simpledialog
import threading
import queue
import json
import os

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_config.json")

def load_config():
    default = {"phrases": ["Hello chat!", "Thanks for the sub!", "BRB", "LOL", "GG"]}
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                return json.load(f)
        except Exception:
            pass
    return default

def save_config(data):
    try:
        with open(CONFIG_PATH, "w") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass

BG       = "#111111"
BG2      = "#1a1a1a"
BG3      = "#161616"
BORDER   = "#2a2a2a"
FG       = "#e8e8e8"
FG2      = "#aaaaaa"
FG3      = "#555555"
FG4      = "#3a3a3a"
GREEN    = "#8bc08b"
GREEN_BG = "#1c2a1c"
GREEN_BD = "#2a3d2a"
RED_FG   = "#884444"
RED_BD   = "#2a1a1a"
FONT_LG  = ("Segoe UI", 18)
FONT_MD  = ("Segoe UI", 11)
FONT_SM  = ("Segoe UI", 9)
FONT_XS  = ("Segoe UI", 8)
FONT_BIG = ("Segoe UI", 13, "bold")


class SpeechEngine(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self._q       = queue.Queue()
        self._sapi    = None
        self._ready   = threading.Event()
        self.on_start = None
        self.on_done  = None
        self.voices   = []

    def run(self):
        import pythoncom, win32com.client
        pythoncom.CoInitialize()
        self._sapi = win32com.client.Dispatch("SAPI.SpVoice")
        tokens = self._sapi.GetVoices()
        for i in range(tokens.Count):
            self.voices.append(tokens.Item(i))
        self._ready.set()
        while True:
            item = self._q.get()
            if item is None:
                break
            text, voice_name, rate, volume = item
            try:
                for v in self.voices:
                    if v.GetDescription() == voice_name:
                        self._sapi.Voice = v
                        break
                self._sapi.Rate   = max(-10, min(10, int((rate - 1.0) * 8)))
                self._sapi.Volume = max(0, min(100, int(volume * 100)))
                if self.on_start:
                    self.on_start()
                self._sapi.Speak(text, 0)
            except Exception as e:
                print("Speak error:", e)
            if self.on_done:
                self.on_done()

    def wait_ready(self):
        self._ready.wait(timeout=10)

    def get_voice_names(self):
        self.wait_ready()
        return [v.GetDescription() for v in self.voices]

    def speak(self, text, voice_name, rate, volume):
        try:
            if self._sapi:
                self._sapi.Speak("", 2)
        except Exception:
            pass
        while not self._q.empty():
            try: self._q.get_nowait()
            except queue.Empty: break
        self._q.put((text, voice_name, rate, volume))

    def stop(self):
        try:
            if self._sapi:
                self._sapi.Speak("", 2)
        except Exception:
            pass
        while not self._q.empty():
            try: self._q.get_nowait()
            except queue.Empty: break

    def shutdown(self):
        self._q.put(None)


class ScrollableFrame(tk.Frame):
    """Vertical-scrollable container with mousewheel support."""
    def __init__(self, parent, bg=BG2, **kw):
        super().__init__(parent, bg=bg, **kw)
        self._canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self._canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self._canvas, bg=bg)
        self._win  = self._canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self._canvas.configure(
            scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>", lambda e: self._canvas.itemconfig(
            self._win, width=e.width))
        self._canvas.bind("<Enter>", lambda e: self._canvas.bind_all(
            "<MouseWheel>", self._scroll))
        self._canvas.bind("<Leave>", lambda e: self._canvas.unbind_all("<MouseWheel>"))

    def _scroll(self, e):
        self._canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")

    def scroll_to_bottom(self):
        self._canvas.update_idletasks()
        self._canvas.yview_moveto(1.0)

    def scroll_to_top(self):
        self._canvas.update_idletasks()
        self._canvas.yview_moveto(0.0)


class StreamerTTS(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Streamer TTS")
        self.geometry("560x700")
        self.resizable(True, True)
        self.configure(bg=BG)
        self.minsize(460, 580)
        self.history = []
        self.config  = load_config()

        self.engine = SpeechEngine()
        self.engine.on_start = lambda: self.after(0, lambda: self._set_status("speaking...", True))
        self.engine.on_done  = lambda: self.after(0, lambda: self._set_status("ready", False))
        self.engine.start()

        self._build_ui()
        self.txt.focus_set()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        threading.Thread(target=self._init_voices, daemon=True).start()
        self._register_hotkeys()

    def _init_voices(self):
        self.engine.wait_ready()
        names = self.engine.get_voice_names()
        self.after(0, lambda: self._populate_voices(names))

    def _populate_voices(self, names):
        self.voice_cb["values"] = names if names else ["Default"]
        self.voice_cb.current(0)
        self._set_status("ready", False)

    def _register_hotkeys(self):
        try:
            import keyboard
            keyboard.add_hotkey("ctrl+shift+space", lambda: self.after(0, self._speak))
            keyboard.add_hotkey("ctrl+shift+s",     lambda: self.after(0, self._stop))
        except Exception as e:
            print("Hotkey error:", e)

    def _on_close(self):
        try:
            import keyboard
            keyboard.unhook_all()
        except Exception:
            pass
        self.engine.shutdown()
        self.destroy()

    def _show_placeholder(self):
        self._ph_active = True
        self.txt.delete("1.0", "end")
        self.txt.insert("1.0", self._ph_text)
        self.txt.config(fg=FG4)

    def _hide_placeholder(self):
        if self._ph_active:
            self._ph_active = False
            self.txt.delete("1.0", "end")
            self.txt.config(fg=FG)

    def _on_focus_in(self, _=None):
        self._hide_placeholder()

    def _on_focus_out(self, _=None):
        if not self.txt.get("1.0", "end").strip():
            self._show_placeholder()

    def _build_ui(self):
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=16, pady=(14, 0))
        tk.Label(top, text="STREAMER TTS", bg=BG, fg=FG3,
                 font=("Segoe UI", 8, "bold")).pack(side="left")
        self.status_dot = tk.Label(top, text="●", bg=BG, fg=FG4,
                                   font=("Segoe UI", 11))
        self.status_dot.pack(side="right")
        self.status_var = tk.StringVar(value="loading voices...")
        tk.Label(top, textvariable=self.status_var, bg=BG, fg=FG3,
                 font=FONT_XS).pack(side="right", padx=(0, 4))

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=16, pady=(10, 0))

        txt_wrap = tk.Frame(self, bg=BG2)
        txt_wrap.pack(fill="both", expand=True, padx=16)
        self.txt = tk.Text(txt_wrap, bg=BG2, fg=FG, insertbackground=FG,
                           font=FONT_LG, wrap="word", relief="flat",
                           padx=14, pady=12, spacing3=4,
                           selectbackground="#2a3a2a", selectforeground=FG,
                           height=4)
        self.txt.pack(fill="both", expand=True)
        self.txt.bind("<Return>", self._on_enter)
        self.txt.bind("<Escape>", lambda e: self._stop())
        self.txt.bind("<FocusIn>",  self._on_focus_in)
        self.txt.bind("<FocusOut>", self._on_focus_out)
        self._ph_active = True
        self._ph_text   = "type to speak..."
        self._show_placeholder()

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=16)

        btn_row = tk.Frame(self, bg=BG)
        btn_row.pack(fill="x", padx=16, pady=(10, 0))
        self._mk_btn(btn_row, "SPEAK", self._speak,
                     bg=GREEN_BG, fg=GREEN, activebg="#1e3020",
                     activefg="#aadaaa", bd_color=GREEN_BD,
                     pady=14, font=FONT_BIG).pack(side="left", fill="x", expand=True)
        self._mk_btn(btn_row, "STOP", self._stop,
                     fg=RED_FG, activebg="#221a1a", activefg="#cc6666",
                     bd_color=RED_BD, pady=14, font=FONT_BIG).pack(
                         side="left", padx=(8, 0), fill="x", expand=True)

        tk.Label(self,
                 text="Ctrl+Shift+Space = speak   Ctrl+Shift+S = stop   Shift+Enter = new line",
                 bg=BG, fg=FG4, font=FONT_XS).pack(anchor="w", padx=16, pady=(5, 0))

        ctrl = tk.Frame(self, bg=BG3)
        ctrl.pack(fill="x", padx=16, pady=(10, 0))
        ic = tk.Frame(ctrl, bg=BG3)
        ic.pack(fill="x", padx=10, pady=8)

        tk.Label(ic, text="voice", bg=BG3, fg=FG3, font=FONT_SM).grid(
            row=0, column=0, sticky="w", padx=(0, 4))
        self.voice_var = tk.StringVar()
        self.voice_cb  = ttk.Combobox(ic, textvariable=self.voice_var,
                                      state="readonly", width=24, font=FONT_SM)
        self._style_combo()
        self.voice_cb.grid(row=0, column=1, sticky="w", padx=(0, 14))

        tk.Label(ic, text="speed", bg=BG3, fg=FG3, font=FONT_SM).grid(
            row=0, column=2, sticky="w", padx=(0, 4))
        self.rate_var = tk.DoubleVar(value=1.0)
        self.rate_lbl = tk.Label(ic, text="1.0x", bg=BG3, fg=FG3, font=FONT_SM, width=4)
        tk.Scale(ic, from_=0.5, to=2.0, resolution=0.1, orient="horizontal",
                 variable=self.rate_var,
                 command=lambda v: self.rate_lbl.config(text=f"{float(v):.1f}x"),
                 bg=BG3, fg=FG3, troughcolor=BG2, highlightthickness=0,
                 showvalue=False, length=80, sliderlength=14).grid(row=0, column=3)
        self.rate_lbl.grid(row=0, column=4, padx=(2, 14))

        tk.Label(ic, text="vol", bg=BG3, fg=FG3, font=FONT_SM).grid(
            row=0, column=5, sticky="w", padx=(0, 4))
        self.vol_var = tk.DoubleVar(value=1.0)
        self.vol_lbl = tk.Label(ic, text="100%", bg=BG3, fg=FG3, font=FONT_SM, width=4)
        tk.Scale(ic, from_=0.0, to=1.0, resolution=0.05, orient="horizontal",
                 variable=self.vol_var,
                 command=lambda v: self.vol_lbl.config(text=f"{round(float(v)*100)}%"),
                 bg=BG3, fg=FG3, troughcolor=BG2, highlightthickness=0,
                 showvalue=False, length=80, sliderlength=14).grid(row=0, column=6)
        self.vol_lbl.grid(row=0, column=7, padx=(2, 0))

        # tabs
        nb = tk.Frame(self, bg=BG)
        nb.pack(fill="both", expand=True, padx=16, pady=(12, 0))
        tab_bar = tk.Frame(nb, bg=BG)
        tab_bar.pack(fill="x")
        self._tab_btns = {}
        for label in ("saved phrases", "history"):
            b = tk.Button(tab_bar, text=label, bg=BG, fg=FG4,
                          font=FONT_SM, relief="flat", cursor="hand2",
                          padx=10, pady=5,
                          command=lambda l=label: self._switch_tab(l))
            b.pack(side="left")
            self._tab_btns[label] = b

        self._tab_content = tk.Frame(nb, bg=BG2)
        self._tab_content.pack(fill="both", expand=True)
        self._active_tab = None

        # phrases panel
        self._phrases_panel = tk.Frame(self._tab_content, bg=BG2)
        ph_top = tk.Frame(self._phrases_panel, bg=BG2)
        ph_top.pack(fill="x", padx=8, pady=(8, 4))
        tk.Label(ph_top, text="click to speak instantly",
                 bg=BG2, fg=FG4, font=FONT_XS).pack(side="left")
        self._mk_btn(ph_top, "+ add", self._add_phrase,
                     font=FONT_XS, pady=3).pack(side="right")
        self._phrases_sf = ScrollableFrame(self._phrases_panel, bg=BG2)
        self._phrases_sf.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self._phrases_frame = self._phrases_sf.inner

        # history panel
        self._history_panel = tk.Frame(self._tab_content, bg=BG2)
        hist_top = tk.Frame(self._history_panel, bg=BG2)
        hist_top.pack(fill="x", padx=8, pady=(8, 4))
        tk.Label(hist_top, text="click to repeat",
                 bg=BG2, fg=FG4, font=FONT_XS).pack(side="left")
        self._mk_btn(hist_top, "clear", self._clear_history,
                     font=FONT_XS, pady=3).pack(side="right")
        self._history_sf = ScrollableFrame(self._history_panel, bg=BG2)
        self._history_sf.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self._hist_frame = self._history_sf.inner

        self._switch_tab("saved phrases")
        self._render_phrases()

        tk.Label(self,
                 text="OBS/Discord: VB-Cable -> set as default playback -> CABLE Output as mic input.",
                 bg=BG, fg=FG4, font=FONT_XS,
                 wraplength=520, justify="left").pack(anchor="w", padx=16, pady=(8, 14))

    def _switch_tab(self, label):
        for lbl, btn in self._tab_btns.items():
            btn.config(fg=FG2 if lbl == label else FG4,
                       font=("Segoe UI", 9, "bold") if lbl == label else FONT_SM)
        if self._active_tab:
            self._active_tab.pack_forget()
        panel = {"saved phrases": self._phrases_panel,
                 "history":       self._history_panel}[label]
        panel.pack(fill="both", expand=True)
        self._active_tab = panel

    def _render_phrases(self):
        for w in self._phrases_frame.winfo_children():
            w.destroy()
        if not self.config["phrases"]:
            tk.Label(self._phrases_frame, text="no phrases yet — click + add",
                     bg=BG2, fg=FG4, font=FONT_XS).pack(pady=12)
            return
        for i, phrase in enumerate(self.config["phrases"]):
            row = tk.Frame(self._phrases_frame, bg=BG2)
            row.pack(fill="x", pady=2)
            btn = tk.Button(row, text=phrase, bg=BG3, fg=FG2,
                            font=FONT_MD, relief="flat", cursor="hand2",
                            anchor="w", padx=10, pady=7,
                            activebackground="#1e2e1e", activeforeground=GREEN,
                            command=lambda p=phrase: self._do_speak(p))
            btn.pack(side="left", fill="x", expand=True)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#1a2a1a"))
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=BG3))
            tk.Button(row, text="x", bg=BG2, fg=FG4, font=FONT_XS,
                      relief="flat", cursor="hand2", padx=8, pady=7,
                      activebackground=BG2, activeforeground=RED_FG,
                      command=lambda idx=i: self._del_phrase(idx)).pack(side="right")

    def _add_phrase(self):
        val = simpledialog.askstring("Add phrase", "Enter phrase:", parent=self)
        if val and val.strip():
            self.config["phrases"].append(val.strip())
            save_config(self.config)
            self._render_phrases()
            self.after(50, self._phrases_sf.scroll_to_bottom)

    def _del_phrase(self, idx):
        self.config["phrases"].pop(idx)
        save_config(self.config)
        self._render_phrases()

    def _render_history(self):
        for w in self._hist_frame.winfo_children():
            w.destroy()
        if not self.history:
            tk.Label(self._hist_frame, text="nothing spoken yet",
                     bg=BG2, fg=FG4, font=FONT_XS).pack(pady=12)
            return
        for phrase in reversed(self.history[-50:]):
            btn = tk.Button(self._hist_frame, text=phrase, bg=BG3, fg=FG3,
                            font=FONT_SM, relief="flat", cursor="hand2",
                            anchor="w", padx=10, pady=6,
                            activebackground="#1a2a1a", activeforeground=FG2,
                            command=lambda p=phrase: self._do_speak(p))
            btn.pack(fill="x", pady=2)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#1a2a1a"))
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=BG3))

    def _clear_history(self):
        self.history.clear()
        self._render_history()

    def _mk_btn(self, parent, text, cmd, bg=BG2, fg=FG2,
                activebg="#222", activefg=FG, bd_color=BORDER,
                pady=9, font=FONT_MD):
        b = tk.Button(parent, text=text, command=cmd,
                      bg=bg, fg=fg, activebackground=activebg,
                      activeforeground=activefg, relief="flat",
                      font=font, cursor="hand2",
                      highlightbackground=bd_color, highlightthickness=1,
                      padx=12, pady=pady)
        b.bind("<Enter>", lambda e: b.config(bg=activebg, fg=activefg))
        b.bind("<Leave>", lambda e: b.config(bg=bg, fg=fg))
        return b

    def _style_combo(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("TCombobox", fieldbackground=BG2, background=BG2,
                    foreground=FG2, bordercolor=BORDER, arrowcolor=FG3,
                    selectbackground=BG2, selectforeground=FG2)
        s.map("TCombobox", fieldbackground=[("readonly", BG2)],
              background=[("readonly", BG2)])

    def _set_status(self, txt, active=False):
        self.status_var.set(txt)
        self.status_dot.config(fg="#3B6D11" if active else FG4)

    def _on_enter(self, event):
        if event.state & 0x1:
            return
        self._speak()
        return "break"

    def _speak(self):
        if self._ph_active:
            return
        text = self.txt.get("1.0", "end").strip()
        if not text:
            return
        self.txt.delete("1.0", "end")
        self.txt.config(fg=FG)
        self._ph_active = False
        self._do_speak(text)
        self.txt.focus_set()

    def _do_speak(self, text):
        self.history.append(text)
        self._render_history()
        self.after(50, self._history_sf.scroll_to_top)
        voice  = self.voice_var.get() or ""
        rate   = self.rate_var.get()
        volume = self.vol_var.get()
        self.engine.speak(text, voice, rate, volume)

    def _stop(self):
        self.engine.stop()
        self._set_status("stopped", False)


if __name__ == "__main__":
    app = StreamerTTS()
    app.mainloop()
