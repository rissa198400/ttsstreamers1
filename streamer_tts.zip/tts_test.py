"""
TTS diagnostic — run this and paste the output back.
python tts_test.py
"""
import subprocess
import sys

print("Python version:", sys.version)
print()

# Test 1: pywin32
print("--- Test 1: pywin32 ---")
try:
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    sapi = win32com.client.Dispatch("SAPI.SpVoice")
    print("SAPI created OK")
    sapi.Speak("message one")
    print("Message 1 OK")
    sapi.Speak("message two")
    print("Message 2 OK")
    sapi.Speak("message three")
    print("Message 3 OK")
    pythoncom.CoUninitialize()
    print("pywin32: ALL PASSED")
except Exception as e:
    print("pywin32 FAILED:", e)

print()

# Test 2: PowerShell
print("--- Test 2: PowerShell ---")
for i in range(1, 4):
    ps = (
        "Add-Type -AssemblyName System.Speech; "
        "$v = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"$v.Speak('message {i}'); "
        "$v.Dispose()"
    )
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
            timeout=15,
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        stderr = r.stderr.decode(errors="ignore").strip()[:120]
        print(f"  Message {i}: returncode={r.returncode}" + (f" error={stderr}" if stderr else " OK"))
    except Exception as e:
        print(f"  Message {i} FAILED:", e)

print()
print("Done — paste everything above back to Claude.")
